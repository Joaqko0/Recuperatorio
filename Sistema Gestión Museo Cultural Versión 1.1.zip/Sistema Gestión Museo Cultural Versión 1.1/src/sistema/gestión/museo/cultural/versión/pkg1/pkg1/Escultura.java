public class Escultura extends Obra implements Exhibible{
    private final int pesoKg;
    public Escultura(String codigo, String autor, EstadoConservacion estado, int pesoKg){
        super(codigo, autor, estado);
        this.pesoKg = validarPositivo(pesoKg, "pesoKg" );
    }
    public int getPesoKg(){
        return pesoKg;
    }
    @Override
    public int calcularCostoMensual(){
        return 80 + pesoKg * 15;
    }
    @Override
    protected String datosEspecificos(){
        return "pesoKg=" + pesoKg;
    }
    @Override
    public String prapararExhibicion(){
        return "exhibicion de Escultura praparada: " + getCodigo();
    }        
}
