/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema.gestión.museo.cultural.versión.pkg1.pkg1;

/**
 *
 * @author Joaqko
 */
public class agregarObra {
    
}
