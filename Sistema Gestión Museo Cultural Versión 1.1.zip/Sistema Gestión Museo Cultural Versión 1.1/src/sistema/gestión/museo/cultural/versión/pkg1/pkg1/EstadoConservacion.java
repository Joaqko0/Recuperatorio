
public enum EstadoConservacion {
    BUENO, REGULAR, DELICADO
}