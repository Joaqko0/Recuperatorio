public class DocumentoAntiguo extends Obra implements Restaurable {
     private final int antiguedadAnios;
    public DocumentoAntiguo(String codigo, String autor, EstadoConservacion estado, int antiguedadAnios){
        super(codigo, autor, estado);
        this.antiguedadAnios = validarPositivo(antiguedadAnios, "antiguedadAnios" );
    }
    public int getAntiguedadAnios(){
        return antiguedadAnios;
    }
    @Override
    public int calcularCostoMensual(){
        return 60 + antiguedadAnios / 5;
    }
    @Override
    protected String datosEspecificos(){
        return "AntiguedadAnios=" + antiguedadAnios;
    }
   @Override
    public String generarPlanRestauracion(){
        return "plan de restatauracion de Documento: " + getCodigo();
    }
}