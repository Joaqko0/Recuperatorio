import java.util.Objects;
/**
 *
 * @author Joaqko
 */
public abstract class Obra {
    private final String codigo;
    private final String autor;
    private final EstadoConservacion estado;
        
    public Obra (String codigo, String autor, EstadoConservacion estado){
        this.codigo = validarTexto(codigo, "codigo");
        this.autor = validarTexto(autor, "autor");
        if (estado == null){
            throw new IllegalArgumentException("El Estado no puee ser NULL");
        }                
        this.estado = estado;
    }
    private static String validarTexto(String valor, String campo) {
        if (valor == null || valor.isBlank()){
            throw new IllegalArgumentException("El " + campo + " no puede ser Null ni estar en blanco.");
        }
        return valor;
    }
    protected static int validarPositivo (int valor, String campo){
        if (valor <= 0){
            throw new IllegalArgumentException("El campo " + campo + " debe ser mayo a cero.");
        }
        return valor;
    }    
    public abstract int calcularCostoMensual();

    protected abstract String datosEspecificos();

    public String getCodigo(){
        return codigo;
    }
    public String getAutor(){
        return autor;
    }
    public EstadoConservacion getEstado(){
        return  estado;
    }
    @Override
    public final boolean equals(Object o){
        if (this == o){
            return true;
        }
        if (!(o instanceof Obra)){
        return false;
        }
        Obra otra = (Obra) o;
        return codigo.equals(otra.codigo) && autor.equals(otra.autor);
    }
    @Override
    public final int hashCode(){
        return Objects.hash(codigo, autor);
    }
    @Override
    public String toString(){
        return getClass().getSimpleName() + "[codigo=" + codigo + ", autor=" + autor + ", estado=" + estado + ", " + datosEspecificos() + ", costos=" + calcularCostoMensual() + "]";
    }
    }