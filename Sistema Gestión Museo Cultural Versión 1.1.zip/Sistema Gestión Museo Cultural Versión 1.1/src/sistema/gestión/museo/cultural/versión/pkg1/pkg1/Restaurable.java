public interface Restaurable {
    String generarPlanRestauracion();
}
