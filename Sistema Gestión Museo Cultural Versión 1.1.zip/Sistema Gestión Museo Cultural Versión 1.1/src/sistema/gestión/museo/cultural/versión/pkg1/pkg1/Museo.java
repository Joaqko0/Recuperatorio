import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *
 * @author Joaqko
 */
public class Museo {
    private final String nombre;
    private final List<Obra> obras;
    private final Set<Obra> obrasRestringidas;
    
    public Museo(String nombre){
        if (nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("el nombre del museo no puede estar vacio");
            
        }
        this.nombre = nombre;
        this.obras = new ArrayList<>();
        this.obrasRestringidas = new HashSet<>();
    }
    public String getNombre(){
        return nombre;
    }
    public void agregarObra (Obra obra) throws ObraDuplicadaException {
        if (obra == null){
            throw new IllegalArgumentException("la obra no puede ser Null");
        }
        if  (obrasRestringidas.contains(obra)){
            throw new ObraDuplicadaException("Ya existe una obra con este codigo");
        }
        obras.add(obra);
        obras.obrasRestringidas.add(obra);
    }
    public List<Obra> obtenerObras() {
        return new ArrayList<>(obras);
    }
    public List<Obra> filtrarPorEstado(EstadoConservacion estado){
        if (estado == null){
            throw new IllegalArgumentException("El estado no puede estar vacio");
        }
        List<Obra> resultado = new ArrayList<>();
        for (Obra obra : obras) {
            if (obra.getEstado() == estado){
                resultado.add(obra);
            }
        }
        return resultado;
    }
    public Obra obtenerObraDeMayorCosto(){
        Obra mayor = null;
        for (Obra obra : obras){
            if (mayor == null || obra.calcularCostoMensual() > mayor.calcularCostoMensual()){
            mayor = obra;
            
            }
        }
        return mayor;
    }
}
