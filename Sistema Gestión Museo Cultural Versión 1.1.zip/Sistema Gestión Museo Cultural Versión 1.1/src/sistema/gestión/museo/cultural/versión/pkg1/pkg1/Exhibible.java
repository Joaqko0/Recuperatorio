
public interface Exhibible {
    String prapararExhibicion();
}
