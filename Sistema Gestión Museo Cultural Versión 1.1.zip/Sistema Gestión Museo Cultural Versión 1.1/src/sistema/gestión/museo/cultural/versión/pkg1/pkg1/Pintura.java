public class Pintura extends Obra implements Restaurable, Exhibible {
    private final int superficieCm2;
    public Pintura(String codigo, String autor, EstadoConservacion estado, int superficieCm2){
        super(codigo, autor, estado);
        this.superficieCm2 = validarPositivo(superficieCm2, "superficieCm2" );
    }
    public int getSuperficieCm2(){
        return superficieCm2;
    }
    @Override
    public int calcularCostoMensual(){
        return 100 + superficieCm2 / 10;
    }
    @Override
    protected String datosEspecificos(){
        return "superficieCm2=" + superficieCm2;
    }
    @Override
    public String generarPlanRestauracion(){
        return "plan de restatauracion de pintura: " + getCodigo();
    }
    @Override
    public String prapararExhibicion(){
        return "exhibicion de pintura praparada: " + getCodigo();
    }
}
