import java.util.List;


/**
 *
 * @author Joaqko
 */
public class Main {
    public static void main(String[] args) {
    Museo museo = new Museo("Museo Aurora");

   
        museo.agregarObra(museo, new Pintura("OB-101", "L. Vega",
                EstadoConservacion.DELICADO, 500));
        museo.agregarObra(new Escultura("OB-102", "M. Solis",
                EstadoConservacion.REGULAR, 12));
        museo.agregarObra(new DocumentoAntiguo("OB-103", "Anonimo",
                EstadoConservacion.DELICADO, 300));
        museo.agregarObra(new Pintura("OB-104", "M. Solis",
                EstadoConservacion.BUENO, 700));
        museo.agregarObra(new Escultura("OB-101", "L. Vega",
                EstadoConservacion.BUENO, 5));
   
    

        System.out.println("Obras registradas:");
        mostrarObras(museo.obtenerObras());
        System.out.println("\nPlanes de restauracion:");
        mostrarRestauraciones(museo.obtenerObras());
        System.out.println("\nPreparacion de exhibiciones:");
        mostrarExhibiciones(museo.obtenerObras());
        System.out.println("\nObras en estado DELICADO:");
        mostrarObras(museo.filtrarPorEstado(EstadoConservacion.DELICADO));
        System.out.println("\nObra de mayor costo:");
        mostrarMayorCosto(museo.obtenerObraDeMayorCosto());
    }
    private static void mostrarObras(List<Obra> obras) {
    // Completar
        if (obras.isEmpty()){
            System.out.println("no hay obras para mostrar");
            return;
        }
        for (Obra obra : obras){
            System.out.println(obra); 
        }
    }
    private static void mostrarRestauraciones(List<Obra> obras) {
    // Completar: indicar si una obra no puede restaurarse
        for (Obra obra : obras){
            if (obra instanceof Restaurable){
                Restaurable r = (Restaurable) obra;
                System.out.println(r.generarPlanRestauracion());
        }
            else {
                    System.out.println("La obra "+ obra.getCodigo() + " no se admite restauracion");
                    }
        }
        
    }
    
    private static void mostrarExhibiciones(List<Obra> obras) {
    // Completar: indicar si una obra no puede exhibirse
        for (Obra obra : obras){
                if (obra instanceof Exhibible){
                Exhibible e = (Exhibible) obra;
                System.out.println(e.prepararExhibicion());
        }
                else {
                        System.out.println("La obra "+ obra.getCodigo() + " no se admite exhibicion");
                        }
    }
    }
    private static void mostrarMayorCosto(Obra obra) {
    // Completar: contemplar una coleccion vacia
        if (obra == null) {
            System.out.println("No hay obras en el museo");
        }
        else {
            System.out.println(obra);
        }
    }
}


